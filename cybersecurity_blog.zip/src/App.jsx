
import React from "react";
import { useState } from "react";

export default function CyberSecurityBlog() {
  const [posts, setPosts] = useState([]);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");

  const addPost = () => {
    if (title && content) {
      const newPost = {
        id: Date.now(),
        title,
        content,
        date: new Date().toLocaleString(),
      };
      setPosts([newPost, ...posts]);
      setTitle("");
      setContent("");
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-4 text-center">
        Cybersecurity Chronicles 🛡️
      </h1>

      <div className="mb-6 border p-4 rounded-md shadow-md">
        <h2 className="text-xl font-semibold mb-2">Share Your Knowledge</h2>
        <input
          type="text"
          placeholder="Post Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="w-full border rounded-md p-2 mb-2"
        />
        <textarea
          placeholder="Your real-time experience or knowledge"
          rows={6}
          value={content}
          onChange={(e) => setContent(e.target.value)}
          className="w-full border rounded-md p-2 mb-2"
        />
        <button onClick={addPost} className="bg-blue-600 text-white py-2 px-4 rounded">
          Publish
        </button>
      </div>

      <div className="space-y-6">
        {posts.length === 0 && (
          <p className="text-center text-gray-500">No posts yet. Be the first to share!</p>
        )}
        {posts.map((post) => (
          <div key={post.id} className="border p-4 rounded-md shadow-md">
            <h3 className="text-2xl font-semibold mb-2">{post.title}</h3>
            <p className="text-sm text-gray-500 mb-4">{post.date}</p>
            <p className="text-base whitespace-pre-line">{post.content}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
